package com.example.chatapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EnterActivity extends AppCompatActivity {
    private EditText mEditText;
    private Button mButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter);
//        Toast.makeText(this,"Welcome to chat!",Toast.LENGTH_LONG).show();
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)!=
                PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},10);
        }
        mEditText =findViewById(R.id.edit_text);
        mButton = findViewById(R.id.enter_btn);
        mButton.setOnClickListener(v-> {
            Intent intent = new Intent(EnterActivity.this, ChatActivity.class);
            intent.putExtra("name",mEditText.getText().toString());
            startActivity(intent);
        });



    }
}
