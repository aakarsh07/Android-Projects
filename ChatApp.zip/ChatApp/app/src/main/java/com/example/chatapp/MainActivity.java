
package com.example.chatapp;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.chatapp.LoginClass;
import com.example.chatapp.R;
import com.example.chatapp.retroFitInterface;

import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    private Retrofit retrofit;
    private retroFitInterface.retrofitInterface RetrofitInterface;
    private String BASE_URL="http://192.168.43.196:3000";
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        RetrofitInterface = retrofit.create(retroFitInterface.retrofitInterface.class);

        findViewById(R.id.login_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleLogin();
            }
        });
        findViewById(R.id.signup_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleSignup();
            }
        });

    }

    private void handleLogin() {
        View view = getLayoutInflater().inflate(R.layout.login_dialogue,null);
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(view).show();
        Button btn =view.findViewById(R.id.login);
        final EditText username = view.findViewById(R.id.login_username);
        final EditText password = view.findViewById(R.id.login_password);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HashMap<String,String>map = new HashMap<>();
                map.put("email",username.getText().toString());
                map.put("password",password.getText().toString());
                Call<LoginClass>call = RetrofitInterface.executeLogin(map);
                call.enqueue(new Callback<LoginClass>() {
                    @Override
                    public void onResponse(Call<LoginClass> call, Response<LoginClass> response) {
                        if(response.code() ==200){
                            LoginClass result = response.body();
//                            AlertDialog.Builder builder1 = new AlertDialog.Builder(MainActivity.this);
//                            builder1.setTitle(result.getName());
//                            builder1.setMessage(result.getEmail());
//                            builder1.show();
                            Toast.makeText(MainActivity.this,"Welcome to chat "+result.getName(),Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(MainActivity.this,EnterActivity.class);
                            startActivity(intent);
                        }else if (response.code()==404){
                            Toast.makeText(MainActivity.this,"WrongCredentials!",Toast.LENGTH_LONG).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<LoginClass> call, Throwable t) {
                        Toast.makeText(MainActivity.this,t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

    }

    private void handleSignup(){
        View view = getLayoutInflater().inflate(R.layout.signup_dialogue,null);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(view).show();
        Button btn =view.findViewById(R.id.signup);
        final EditText name = view.findViewById(R.id.name);
        final EditText email =view.findViewById(R.id.signup_username);
        final EditText password =view.findViewById(R.id.signup_password);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HashMap<String,String>map=new HashMap<>();
                map.put("name", name.getText().toString());
                map.put("email", email.getText().toString());
                map.put("password", password.getText().toString());
                Call<Void>call=RetrofitInterface.executeSignup(map);
                call.enqueue(new Callback<Void>() {

                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        if(response.code() ==200){
                            Toast.makeText(MainActivity.this,"signed up successfully!",Toast.LENGTH_LONG).show();
                        }else if (response.code()==400){
                            Toast.makeText(MainActivity.this,"alreadyRegistered",Toast.LENGTH_LONG).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<Void> call, Throwable t) {
                        Toast.makeText(MainActivity.this,t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

            }
        });

    }
}
